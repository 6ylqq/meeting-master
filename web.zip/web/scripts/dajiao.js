function badgeDispose(event){
	var element = event.srcElement.getElementsByTagName('span')[0];
	console.log(element.html());
}
